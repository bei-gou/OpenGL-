var searchData=
[
  ['user_0',['user',['../struct_g_l_f_wallocator.html#af6153be74dbaf7f0a7e8bd3bfc039910',1,'GLFWallocator']]]
];
